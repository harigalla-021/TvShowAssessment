// import { shallowMount } from '@vue/test-utils'

// import dashboard from '@/views/DashBoard.vue'

describe('dashboard.vue', () => {
  it('Dashboard Component exists', () => {
    expect(true).toBe(true)
  })
})
