// import { shallowMount } from '@vue/test-utils'

// import details from '@/views/Details.vue'

describe('details.vue', () => {
  it('details Component exists', () => {
    expect(true).toBe(true)
  })
})
