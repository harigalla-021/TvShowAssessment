// import { shallowMount } from '@vue/test-utils'

// import showinfo from '@/components/ShowInfo.vue'

describe('showinfo.vue', () => {
  it('showinfo Component exists', () => {
    expect(true).toBe(true)
  })
})
