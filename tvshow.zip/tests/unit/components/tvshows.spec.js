// import { shallowMount } from '@vue/test-utils'

// import tvshows from '@/components/TvShows.vue'

describe('tvshows.vue', () => {
  it('tvshows Component exists', () => {
    expect(true).toBe(true)
  })
})
