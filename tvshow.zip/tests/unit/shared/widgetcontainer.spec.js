// import { shallowMount } from '@vue/test-utils'

// import widgetcontainer from '@/shared/WidgetContainer.vue'

describe('widgetcontainer.vue', () => {
  it('widgetcontainer Component exists', () => {
    expect(true).toBe(true)
  })
})
