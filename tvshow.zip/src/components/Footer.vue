<template>
  <v-footer color="primary">
    <v-col class="white--text">
      &copy;2020 —
      <strong>TvShows Page</strong>
    </v-col>
  </v-footer>
</template>


<script>
export default {
  name: "AppFooter"
};
</script>