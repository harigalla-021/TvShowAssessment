<template>
  <v-footer color="primary">
    <vcard align-center>
      <v-card-text class="white--text text-md-center">
        &copy;2020 —
        <strong>TvShows Page</strong>
      </v-card-text>
    </vcard>
  </v-footer>
</template>


<script>
export default {
  name: "AppFooter"
};
</script>